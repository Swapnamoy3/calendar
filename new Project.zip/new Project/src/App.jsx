import { useState } from "react";
import reactLogo from "./assets/react.svg";
// import viteLogo from '/vite.svg'
import "./App.css";
import Day from "../Components/jsx/Day";
import Month from "../Components/jsx/Month";
function App() {
  return <Month month="Feburary" />;
}

export default App;
